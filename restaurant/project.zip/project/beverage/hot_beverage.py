# from restaurant.project.beverage.beverage import Beverage
from project.beverage.beverage import Beverage


class HotBeverage(Beverage):
    pass
