class Software:
    def __init__(self,name: str, type: str, capacity_consumption: int, memory_consumption: int):
        self.name: str = name
        self.type: str = ("Express", "Light")
        self.capacity_consumption: int = capacity_consumption
        self.memory_consumption: int = memory_consumption
